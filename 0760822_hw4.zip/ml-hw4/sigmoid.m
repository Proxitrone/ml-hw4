function y = sigmoid(x)
%SIGMOID Sigmoid logistic function
%   Detailed explanation goes here
    y = 1./(1+exp(-x));
end

